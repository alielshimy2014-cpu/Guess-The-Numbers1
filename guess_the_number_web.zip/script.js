let randomNumber;
let min, max;

document.getElementById('start-game').addEventListener('click', () => {
    min = parseInt(document.getElementById('min').value);
    max = parseInt(document.getElementById('max').value);

    if (isNaN(min) || isNaN(max) || min >= max) {
        alert("Please enter a valid range!");
        return;
    }

    randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;

    document.querySelector('.range-inputs').style.display = 'none';
    document.querySelector('.guess-section').style.display = 'block';
    document.getElementById('message').textContent = "";
});

document.getElementById('check').addEventListener('click', () => {
    const guess = parseInt(document.getElementById('guess').value);

    if (isNaN(guess)) {
        document.getElementById('message').textContent = "Please enter a number!";
        return;
    }

    if (guess < randomNumber) {
        document.getElementById('message').textContent = "Too low! Try again.";
    } else if (guess > randomNumber) {
        document.getElementById('message').textContent = "Too high! Try again.";
    } else {
        document.getElementById('message').textContent = `🎉 Correct! The number was ${randomNumber}.`;
    }
});